﻿using SETCorp.Adapters.NFe;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace Set.Web.Api.Host.Models
{
    public class NFeViewModel
    {
        public dynamic NFe { get; set; }
        public dynamic ProtNFe { get; set; }

        public NFeViewModel()
        {
            var file = VirtualPathUtility.ToAbsolute("~/NFe28090708060730000190550020000001762000007303procNFe.xml");
            var path = Path.GetFullPath(file);

            var deserializer = new NFeDeserializer();
            this.NFe = deserializer.DeserializeNFe(path);
            this.ProtNFe = deserializer.DeserializeProtNFe(path);
        }
    }
}