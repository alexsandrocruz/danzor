﻿using Set.Web.Api.Host.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Set.Web.Api.Host.Controllers
{
    public class DanfeController : Controller
    {
        // GET: Danfe
        public ActionResult Danfe()
        {
            
            
            
            var danfe = new NFeViewModel();
            return View(danfe);
        }
    }
}