﻿using SETCorp.Adapters.NFe;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SETCorp.Adapters.Tests.Helpers
{
    public class NFeDeserializerFactory
    {
        public static dynamic NFe28090708060730000190550020000001762000007303
        {
            get
            {
                var deserializer = new NFeDeserializer();
                return deserializer.DeserializeNFe(GetFilePath());
            }
        }

        private static string GetFilePath()
        {
            var path = @"Helpers\NFe28090708060730000190550020000001762000007303procNFe.xml";
            return new FileInfo(path).FullName;
        }
    }
}
